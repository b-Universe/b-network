Tiny Emoji Font resource pack for Minecraft Java Edition

To use, simply install and enable the resource pack and you're ready to insert standard emoji characters anywhere.

Includes translations for emoji shortcodes:
```json
{"translate": ":thinking:"}
```

Full support for sequences such as flags, skintone, gender and other modifiers requires modding the server and/or client to remap these sequences to single characters (see remapping.json).

Graphics based on Twemoji Copyright (c) 2018 Twitter, Inc and other contributors, licensed under Creative Commons Attribution 4.0 International
Pixel art and resource pack adaptation Copyright (c) 2020 Amber, also licensed under Creative Commons Attribution 4.0 International